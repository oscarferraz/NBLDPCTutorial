#!/bin/bash

rm data/times.txt

for i in {1..20}
do


 ./min_max

	
done

